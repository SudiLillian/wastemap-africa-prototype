# WasteMap Africa Interview Prep

## One-sentence description

WasteMap Africa helps city teams identify where waste and drainage problems are most likely to increase flood risk, then decide which sites to inspect, clear and monitor first.

## A simple opening answer

WasteMap Africa is not just a waste map. It is a practical planning tool for cities. Community reporters capture a photo, location and drainage condition. The report is checked, combined with basic flood and exposure data, and turned into a clear list of priority sites for county teams. The immediate goal is to test this approach in Nairobi and prove that it can improve how limited drainage and clean-up resources are used.

## What are the biggest obstacles to achieving your vision?

The biggest obstacle is building trust in the data. A city will only act if reports are accurate, recent and easy to verify. That means training reporters, checking locations and photos, removing duplicates and keeping a clear review trail.

The second obstacle is adoption inside government. The product must fit the way county teams already assign work, manage budgets and respond before and during heavy rain. A useful map is not enough. We need county staff to test the recommendations, act on them and report what happened.

The third obstacle is proving impact. We need to show that acting on a priority site leads to better drainage, fewer repeat blockages or lower flood disruption. That requires baseline data, follow-up visits and observation across more than one rainy season.

The fourth obstacle is sustainability. We need a model that can pay for field reporting, supervision, data maintenance and follow-up after a pilot ends. This may involve county contracts, climate adaptation funding, waste partnerships and support from development organisations.

Collector safety, privacy and responsible use of location data are also important. These controls need to be built into the pilot from the start.

## How would you spend $5,000 right now?

I would use $5,000 to run a focused six to eight week pilot in one high-risk area. The goal would be to test the full workflow from field report to county action.

| Use | Amount |
| --- | ---: |
| Train and support 10 to 12 community reporters and one supervisor | $2,000 |
| Data bundles, local transport, safety equipment and shared field devices | $800 |
| Configure field forms, validation rules and a simple dashboard | $1,200 |
| Joint site checks and working sessions with county staff | $600 |
| Baseline, follow-up checks and a short pilot report | $400 |
| **Total** | **$5,000** |

The result should be a small but credible proof that reports can be collected, checked and used to guide a real response.

## How would you spend $25,000?

I would use $25,000 for a four to six month pilot across three communities, with a stronger measurement plan and regular participation from county teams.

| Use | Amount |
| --- | ---: |
| Field operations, reporter payments and supervision | $8,000 |
| Product improvements, database, dashboard and reporting tools | $5,000 |
| Drainage, rainfall and exposure analysis | $3,000 |
| County co-design sessions and response exercises | $3,000 |
| Monitoring, evaluation and independent data checks | $3,000 |
| Programme management, safety, legal support and contingency | $3,000 |
| **Total** | **$25,000** |

At this level, I would want to prove three things: the data is reliable, county teams use it, and selected interventions produce a measurable improvement.

## How would you spend $250,000?

I would use $250,000 for a 12 to 18 month city-level pilot covering several high-risk wards. The aim would be to build a repeatable model that another county could adopt.

| Use | Amount |
| --- | ---: |
| Core team for product, geospatial analysis, field operations and partnerships | $75,000 |
| Community reporting network, supervision, equipment and field logistics | $55,000 |
| County integration, response coordination and targeted intervention support | $40,000 |
| Product development, hosting, data security and system maintenance | $35,000 |
| Independent monitoring and impact evaluation across rainy seasons | $20,000 |
| Community partnerships, safety, privacy and compliance | $15,000 |
| Contingency | $10,000 |
| **Total** | **$250,000** |

I would not spend the money on a large custom predictive system before the workflow is proven. The priority would be reliable field data, county use, measurable outcomes and a model that can continue after the grant.

## Strong closing line

The funding would help us move from a convincing prototype to evidence that a city can use community reports to make faster, better and more accountable flood-prevention decisions.
