/* WasteMap Africa - browser-only interactive prototype.
   All operational figures in this demo are simulated. */

const COLORS = {
  blue: '#1976D2', blueDark: '#0b4f83', green: '#2E7D32', orange: '#FB8C00',
  red: '#D32F2F', grey: '#757575', teal: '#00796b', purple: '#6f42c1'
};

const alertData = [
  { level: 'critical', icon: 'triangle-alert', title: 'Kibera East: drain network at 8% capacity', body: '64 blocked drains and 3 schools exposed.', time: '12 min ago', priority: 'CRITICAL' },
  { level: 'critical', icon: 'cloud-rain', title: 'Mathare North: rainfall threshold exceeded', body: 'River-adjacent homes likely affected first.', time: '29 min ago', priority: 'CRITICAL' },
  { level: 'warning', icon: 'trash-2', title: 'Mukuru: new waste obstruction detected', body: 'Collector report awaiting supervisor validation.', time: '54 min ago', priority: 'HIGH' },
  { level: 'warning', icon: 'route', title: 'Korogocho market road at risk', body: 'Drain KG-D09 is fully blocked upstream.', time: '1 hr ago', priority: 'HIGH' },
  { level: 'info', icon: 'check-circle-2', title: 'K-D07 intervention verified', body: 'Post-rain inspection shows improved flow.', time: '2 hrs ago', priority: 'MEDIUM' }
];

const zones = [
  {
    id:'mathare', name:'Mathare', ward:'Mathare North', risk:94, riskLevel:'high',
    polygon:[[-1.2560,36.8510],[-1.2555,36.8645],[-1.2602,36.8723],[-1.2705,36.8702],[-1.2730,36.8582],[-1.2662,36.8502]],
    center:[-1.2644,36.8614], blocked:14, totalBlocked:52, waste:48, population:9200,
    drainCapacity:12, floodEvents:5, cost:'KES 2.4M', reduction:'72%',
    infrastructure:[['school','Mathare North Primary','460 learners'],['hospital','Mathare Health Centre','Primary care facility'],['bridge','River Road footbridge','Critical access route']],
    actions:[['Drain cleaning','Clear 14 priority drains within 72 hours'],['Waste removal','Remove 48 tonnes near channel inlets'],['Trash trap','Install upstream capture at Channel 3']],
    description:'Dense settlement beside the Mathare River with recurring obstruction at narrow drainage crossings.'
  },
  {
    id:'kibera', name:'Kibera', ward:'Kibera East', risk:91, riskLevel:'high',
    polygon:[[-1.3040,36.7750],[-1.3038,36.7890],[-1.3095,36.8005],[-1.3205,36.7995],[-1.3250,36.7865],[-1.3175,36.7750]],
    center:[-1.3137,36.7878], blocked:18, totalBlocked:64, waste:62, population:14800,
    drainCapacity:8, floodEvents:6, cost:'KES 3.8M', reduction:'76%',
    infrastructure:[['school','Olympic Primary access','Road and pedestrian access'],['hospital','Kibera South Clinic','Access route threatened'],['bridge','Line 7 crossing','Known overflow point']],
    actions:[['Emergency clearance','Deploy two teams to 18 critical drains'],['Capacity upgrade','Open temporary bypass at Lines 4 and 7'],['Community warning','Issue SMS and local radio alert']],
    description:'Highest-risk pilot zone, where constrained drainage and dense exposure amplify even moderate rainfall.'
  },
  {
    id:'korogocho', name:'Korogocho', ward:'Korogocho Central', risk:67, riskLevel:'medium',
    polygon:[[-1.2528,36.8790],[-1.2532,36.8910],[-1.2595,36.8970],[-1.2685,36.8935],[-1.2690,36.8832],[-1.2613,36.8775]],
    center:[-1.2610,36.8870], blocked:9, totalBlocked:40, waste:31, population:6100,
    drainCapacity:31, floodEvents:3, cost:'KES 1.7M', reduction:'55%',
    infrastructure:[['school','Daniel Comboni Primary','Low-lying approach'],['hospital','Korogocho Health Centre','Medium exposure'],['bridge','Market channel crossing','Waste accumulation point']],
    actions:[['Market drain clearance','Prioritise KG-D09 and KG-D17'],['Hazardous waste review','Escalate contamination risk near inlet'],['Monitoring','Inspect after each heavy rainfall event']],
    description:'Growing drainage risk near market channels and waste accumulation routes adjacent to the Dandora area.'
  },
  {
    id:'mukuru', name:'Mukuru', ward:'Mukuru kwa Reuben', risk:82, riskLevel:'high',
    polygon:[[-1.3060,36.8510],[-1.3040,36.8725],[-1.3140,36.8820],[-1.3260,36.8750],[-1.3280,36.8540],[-1.3180,36.8460]],
    center:[-1.3165,36.8634], blocked:12, totalBlocked:47, waste:39, population:11700,
    drainCapacity:16, floodEvents:4, cost:'KES 2.9M', reduction:'69%',
    infrastructure:[['school','Mukuru Community School','Flood-prone entrance'],['hospital','Mukuru Health Post','Access road exposed'],['bridge','Ngong River crossing','Critical pedestrian link']],
    actions:[['Drain desilting','Clear industrial sediment and waste'],['Road protection','Protect two access-road culverts'],['Trash capture','Install two modular trash traps']],
    description:'Industrial runoff, narrow culverts and waste obstruction combine to threaten access roads and riverside homes.'
  }
];

const drains = [
  {id:'M-D14',lat:-1.2635,lng:36.8618,status:'blocked',capacity:0,zone:'Mathare',waste:'2.3 t plastic',action:'Immediate clearance'},
  {id:'M-D22',lat:-1.2672,lng:36.8650,status:'blocked',capacity:0,zone:'Mathare',waste:'1.1 t mixed',action:'Immediate clearance'},
  {id:'M-D08',lat:-1.2604,lng:36.8576,status:'over',capacity:12,zone:'Mathare',waste:'0.4 t organic',action:'Clear within 7 days'},
  {id:'M-D05',lat:-1.2665,lng:36.8552,status:'clear',capacity:78,zone:'Mathare',waste:'None',action:'Routine monitoring'},
  {id:'K-D07',lat:-1.3127,lng:36.7867,status:'blocked',capacity:0,zone:'Kibera',waste:'4.1 t mixed',action:'Immediate clearance'},
  {id:'K-D19',lat:-1.3161,lng:36.7922,status:'blocked',capacity:0,zone:'Kibera',waste:'2.7 t plastic',action:'Immediate clearance'},
  {id:'K-D03',lat:-1.3098,lng:36.7828,status:'over',capacity:8,zone:'Kibera',waste:'1.9 t organic',action:'Temporary bypass'},
  {id:'K-D01',lat:-1.3087,lng:36.7798,status:'clear',capacity:65,zone:'Kibera',waste:'None',action:'Routine monitoring'},
  {id:'KG-D09',lat:-1.2608,lng:36.8872,status:'blocked',capacity:0,zone:'Korogocho',waste:'1.5 t hazardous',action:'Clear and inspect contamination'},
  {id:'KG-D04',lat:-1.2583,lng:36.8831,status:'over',capacity:22,zone:'Korogocho',waste:'0.9 t plastic',action:'Clear within 14 days'},
  {id:'KG-D02',lat:-1.2642,lng:36.8910,status:'clear',capacity:71,zone:'Korogocho',waste:'None',action:'Routine monitoring'},
  {id:'MK-D12',lat:-1.3151,lng:36.8615,status:'blocked',capacity:0,zone:'Mukuru',waste:'3.2 t mixed',action:'Immediate clearance'},
  {id:'MK-D21',lat:-1.3200,lng:36.8692,status:'over',capacity:16,zone:'Mukuru',waste:'1.4 t construction debris',action:'Desilt and clear'},
  {id:'MK-D05',lat:-1.3120,lng:36.8560,status:'clear',capacity:62,zone:'Mukuru',waste:'None',action:'Routine monitoring'}
];

const dumpsites = [
  {id:'W-1042',lat:-1.2631,lng:36.8640,zone:'Mathare',type:'Mixed waste',tonnes:4.8,nearDrain:'M-D14',risk:'High'},
  {id:'W-1057',lat:-1.2682,lng:36.8673,zone:'Mathare',type:'Plastic',tonnes:2.1,nearDrain:'M-D22',risk:'High'},
  {id:'W-1188',lat:-1.3146,lng:36.7906,zone:'Kibera',type:'Mixed waste',tonnes:6.3,nearDrain:'K-D19',risk:'High'},
  {id:'W-1201',lat:-1.3108,lng:36.7844,zone:'Kibera',type:'Plastic',tonnes:5.1,nearDrain:'K-D07',risk:'High'},
  {id:'W-1322',lat:-1.2601,lng:36.8891,zone:'Korogocho',type:'Hazardous',tonnes:1.2,nearDrain:'KG-D09',risk:'High'},
  {id:'W-1410',lat:-1.3168,lng:36.8657,zone:'Mukuru',type:'Construction debris',tonnes:5.4,nearDrain:'MK-D12',risk:'High'}
];

const assets = [
  {type:'school',name:'Mathare North Primary',lat:-1.2603,lng:36.8602,zone:'Mathare',exposure:'High',people:'460 learners'},
  {type:'clinic',name:'Mathare Health Centre',lat:-1.2665,lng:36.8680,zone:'Mathare',exposure:'High',people:'1,200 weekly visits'},
  {type:'school',name:'Olympic Primary',lat:-1.3120,lng:36.7820,zone:'Kibera',exposure:'High',people:'2,100 learners'},
  {type:'clinic',name:'Kibera South Clinic',lat:-1.3190,lng:36.7940,zone:'Kibera',exposure:'Medium',people:'860 weekly visits'},
  {type:'school',name:'Daniel Comboni Primary',lat:-1.2585,lng:36.8885,zone:'Korogocho',exposure:'Medium',people:'720 learners'},
  {type:'clinic',name:'Korogocho Health Centre',lat:-1.2653,lng:36.8845,zone:'Korogocho',exposure:'Medium',people:'640 weekly visits'},
  {type:'school',name:'Mukuru Community School',lat:-1.3138,lng:36.8670,zone:'Mukuru',exposure:'High',people:'830 learners'},
  {type:'clinic',name:'Mukuru Health Post',lat:-1.3232,lng:36.8586,zone:'Mukuru',exposure:'High',people:'540 weekly visits'}
];

const riverLines = [
  [[-1.252,36.845],[-1.258,36.855],[-1.264,36.866],[-1.270,36.878]],
  [[-1.301,36.770],[-1.307,36.782],[-1.314,36.790],[-1.322,36.803]],
  [[-1.303,36.842],[-1.312,36.855],[-1.321,36.872],[-1.328,36.887]]
];

const roadLines = [
  [[-1.248,36.848],[-1.280,36.883]],
  [[-1.300,36.768],[-1.330,36.805]],
  [[-1.300,36.842],[-1.333,36.887]],
  [[-1.250,36.875],[-1.275,36.899]]
];

const recommendations = [
  {id:'mathare-4',rank:1,location:'Mathare Ward 4',title:'Clear channel drains and install trash trap',priority:5,reduction:72,cost:2.4,population:8400,time:'72 hours',owner:'Environment + Roads',evidence:'14 blocked drains; 48 tonnes near inlets',steps:['Deploy two drain-cleaning teams','Remove waste from Channel 3 and River Road junction','Install modular trash trap upstream','Reinspect after next heavy rainfall']},
  {id:'kibera-east',rank:2,location:'Kibera East',title:'Emergency drain clearance and temporary bypass',priority:5,reduction:76,cost:3.8,population:11800,time:'48 hours',owner:'Disaster Management + Water',evidence:'Network at 8% capacity; 3 schools exposed',steps:['Clear K-D07 and K-D19 immediately','Open temporary flow bypass at Line 7','Issue community flood alert','Review upgrade design after rains']},
  {id:'mukuru-reuben',rank:3,location:'Mukuru kwa Reuben',title:'Desilt culverts and protect access roads',priority:4,reduction:69,cost:2.9,population:7200,time:'7 days',owner:'Roads + Environment',evidence:'Industrial sediment and waste at two culverts',steps:['Desilt MK-D12 and MK-D21','Clear construction debris','Protect culvert shoulders','Install rainfall-triggered inspection plan']},
  {id:'korogocho-market',rank:4,location:'Korogocho Market',title:'Remove hazardous obstruction and inspect inlet',priority:4,reduction:55,cost:1.7,population:4400,time:'7 days',owner:'Public Health + Environment',evidence:'Hazardous waste mapped at KG-D09',steps:['Isolate hazardous material','Clear drainage inlet safely','Inspect downstream contamination','Engage market waste handlers']},
  {id:'mathare-bridge',rank:5,location:'Mathare River Road',title:'Protect bridge access and reinforce warning system',priority:3,reduction:43,cost:1.3,population:2600,time:'14 days',owner:'Roads + Disaster Management',evidence:'Footbridge isolates residents during overflow',steps:['Mark alternative route','Install water-level marker','Clear bridge opening','Add alert to county warning workflow']},
  {id:'kibera-school',rank:6,location:'Olympic Primary access',title:'Improve school drainage and safe access route',priority:3,reduction:38,cost:2.1,population:2100,time:'30 days',owner:'Education + Roads',evidence:'School approach floods after moderate rainfall',steps:['Open roadside drain','Raise pedestrian crossing','Install warning signage','Monitor school-day access']}
];

const chartInstances = {};
const mapState = { dashboard:null, intelligence:null, layers:{}, dashboardLayers:[] };
let currentView = 'dashboard';
let selectedRecommendation = recommendations[0];

function safeIcon(name, size = 16) {
  return `<i data-lucide="${name}" style="width:${size}px;height:${size}px"></i>`;
}

function renderIcons(root = document) {
  if (window.lucide) window.lucide.createIcons({attrs:{'stroke-width':1.9}, root});
}

function initNavigation() {
  const links = [...document.querySelectorAll('.nav-link')];
  const goButtons = [...document.querySelectorAll('[data-go]')];
  function navigate(view, updateHash = true) {
    const target = document.getElementById(`view-${view}`) ? view : 'dashboard';
    currentView = target;
    document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === `view-${target}`));
    links.forEach(el => el.classList.toggle('active', el.dataset.view === target));
    const active = document.getElementById(`view-${target}`);
    document.getElementById('pageTitle').textContent = active.dataset.title;
    if (updateHash) history.replaceState(null, '', `#${target}`);
    document.getElementById('sidebar').classList.remove('open');
    onViewShown(target);
    window.scrollTo({top:0, behavior:'smooth'});
  }
  links.forEach(link => link.addEventListener('click', e => { e.preventDefault(); navigate(link.dataset.view); }));
  goButtons.forEach(button => button.addEventListener('click', () => navigate(button.dataset.go)));
  window.addEventListener('hashchange', () => navigate(location.hash.slice(1), false));
  document.getElementById('menuButton').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));
  document.addEventListener('click', e => {
    if (innerWidth > 820) return;
    const sidebar = document.getElementById('sidebar');
    if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && !document.getElementById('menuButton').contains(e.target)) sidebar.classList.remove('open');
  });
  navigate(location.hash.slice(1) || 'dashboard', false);
}

function onViewShown(view) {
  setTimeout(() => {
    if (view === 'dashboard') {
      initDashboardMap();
      mapState.dashboard?.invalidateSize();
      initDashboardCharts();
    }
    if (view === 'map') {
      initIntelligenceMap();
      mapState.intelligence?.invalidateSize();
    }
    if (view === 'evidence') initEvidenceCharts();
    if (view === 'decisions') renderRecommendations();
  }, 50);
}

function renderAlerts() {
  const container = document.getElementById('dashboardAlerts');
  container.innerHTML = alertData.map(a => `
    <div class="alert-item">
      <span class="alert-icon ${a.level}">${safeIcon(a.icon,14)}</span>
      <div><strong>${a.title}</strong><p>${a.body}</p><small>${a.time}</small></div>
      <span class="priority-chip ${a.level === 'warning' ? 'high' : a.level}">${a.priority}</span>
    </div>`).join('');
  renderIcons(container);
}

function tileLayers() {
  const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom:19, attribution:'&copy; OpenStreetMap contributors'
  });
  const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom:19, attribution:'Tiles &copy; Esri'
  });
  return {street, satellite};
}

function addZonesToMap(map, clickHandler, compact = false) {
  return zones.map(zone => {
    const color = zone.riskLevel === 'high' ? COLORS.red : zone.riskLevel === 'medium' ? COLORS.orange : COLORS.green;
    const polygon = L.polygon(zone.polygon, {color, weight:compact?1.3:2, fillColor:color, fillOpacity:compact?.18:.22});
    polygon.on('click', () => clickHandler(zone));
    polygon.bindTooltip(`${zone.name} • ${zone.risk}% risk`, {sticky:true});
    polygon.addTo(map);
    const label = L.marker(zone.center, {interactive:true, icon:L.divIcon({className:'custom-zone-label',html:`<div class="zone-label ${zone.riskLevel}">${zone.name} · ${zone.risk}%</div>`,iconAnchor:[38,10]})});
    label.on('click', () => clickHandler(zone));
    label.addTo(map);
    return {polygon,label,zone};
  });
}

function drainStyle(status) {
  if (status === 'blocked') return {fill:COLORS.red,stroke:'#f59a9a'};
  if (status === 'over') return {fill:COLORS.orange,stroke:'#ffd08a'};
  return {fill:COLORS.green,stroke:'#9bd19e'};
}

function addDrainsToMap(map, clickHandler, small = false) {
  return drains.map(d => {
    const c = drainStyle(d.status);
    const marker = L.circleMarker([d.lat,d.lng], {radius:small?4.5:6, fillColor:c.fill, color:c.stroke, weight:2, fillOpacity:.95});
    marker.bindTooltip(`${d.id}: ${d.status === 'over' ? 'over capacity' : d.status}`);
    marker.on('click', () => clickHandler(d));
    marker.addTo(map);
    return marker;
  });
}

function addDumpsitesToMap(map, clickHandler, small = false) {
  return dumpsites.map(d => {
    const marker = L.circleMarker([d.lat,d.lng], {radius:small?5:7 + Math.min(3,d.tonnes/3),fillColor:'#5c6570',color:'#f4f6f8',weight:2,fillOpacity:.92});
    marker.bindTooltip(`${d.id}: ${d.tonnes} t ${d.type}`);
    marker.on('click', () => clickHandler(d));
    marker.addTo(map);
    return marker;
  });
}

function initDashboardMap() {
  if (mapState.dashboard) return;
  const layers = tileLayers();
  const map = L.map('dashboardMap', {zoomControl:true,scrollWheelZoom:false,attributionControl:true}).setView([-1.291,36.838],12);
  layers.street.addTo(map);
  mapState.dashboard = map;
  const zoneLayers = addZonesToMap(map, zone => { navigateToMapZone(zone); }, true);
  const drainLayers = addDrainsToMap(map, drain => { navigateToMapDrain(drain); }, true);
  const dumpLayers = addDumpsitesToMap(map, dump => { navigateToMapDump(dump); }, true);
  mapState.dashboardLayers = [...zoneLayers.flatMap(z=>[z.polygon,z.label]),...drainLayers,...dumpLayers];

  document.querySelectorAll('[data-dashboard-filter]').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('[data-dashboard-filter]').forEach(b => b.classList.toggle('active', b === button));
      const filter = button.dataset.dashboardFilter;
      mapState.dashboardLayers.forEach(layer => { if (map.hasLayer(layer)) map.removeLayer(layer); });
      if (filter === 'all') mapState.dashboardLayers.forEach(layer => layer.addTo(map));
      if (filter === 'critical') {
        zoneLayers.filter(z=>z.zone.risk>=85).flatMap(z=>[z.polygon,z.label]).forEach(l=>l.addTo(map));
        drainLayers.filter((_,i)=>drains[i].status==='blocked').forEach(l=>l.addTo(map));
      }
      if (filter === 'today') {
        zoneLayers.filter(z=>['Mathare','Mukuru'].includes(z.zone.name)).flatMap(z=>[z.polygon,z.label]).forEach(l=>l.addTo(map));
        drainLayers.filter((_,i)=>['M-D14','M-D22','MK-D12'].includes(drains[i].id)).forEach(l=>l.addTo(map));
        dumpLayers.filter((_,i)=>['Mathare','Mukuru'].includes(dumpsites[i].zone)).forEach(l=>l.addTo(map));
      }
    });
  });
}

function navigateToMapZone(zone) {
  history.replaceState(null,'','#map');
  document.querySelector('.nav-link[data-view="map"]').click();
  setTimeout(() => { mapState.intelligence?.fitBounds(zone.polygon,{padding:[25,25]}); showZoneInsight(zone); },120);
}
function navigateToMapDrain(drain) {
  history.replaceState(null,'','#map'); document.querySelector('.nav-link[data-view="map"]').click();
  setTimeout(()=>{mapState.intelligence?.setView([drain.lat,drain.lng],16);showDrainInsight(drain);},120);
}
function navigateToMapDump(dump) {
  history.replaceState(null,'','#map'); document.querySelector('.nav-link[data-view="map"]').click();
  setTimeout(()=>{mapState.intelligence?.setView([dump.lat,dump.lng],16);showDumpInsight(dump);},120);
}

function initDashboardCharts() {
  if (chartInstances.riskTrend) return;
  chartInstances.riskTrend = new Chart(document.getElementById('riskTrendChart'), {
    type:'line', data:{labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],datasets:[{data:[61,65,68,70,74,80,86],borderColor:COLORS.red,backgroundColor:'rgba(211,47,47,.10)',fill:true,tension:.38,pointRadius:2.5,pointBackgroundColor:COLORS.red}]},
    options:chartOptions({yMin:40,yMax:100,suffix:'%'})
  });
}

function chartOptions({yMin=0,yMax, suffix='', legend=false, indexAxis='x'}={}) {
  return {responsive:true,maintainAspectRatio:false,indexAxis,plugins:{legend:{display:legend},tooltip:{callbacks:{label:(ctx)=>`${ctx.dataset.label?ctx.dataset.label+': ':''}${ctx.parsed.y ?? ctx.parsed.x}${suffix}`}}},scales:{x:{grid:{display:false},ticks:{font:{size:8},color:'#7c8996'}},y:{min:yMin,max:yMax,grid:{color:'rgba(120,140,160,.12)'},ticks:{font:{size:8},color:'#7c8996',callback:v=>`${v}${suffix}`}}}};
}

function initIntelligenceMap() {
  if (mapState.intelligence) return;
  const {street,satellite} = tileLayers();
  const map = L.map('intelligenceMap',{zoomControl:true,scrollWheelZoom:true}).setView([-1.291,36.838],12);
  street.addTo(map);
  mapState.intelligence = map;
  mapState.layers.baseStreet = street;
  mapState.layers.baseSatellite = satellite;

  const zoneGroup = L.layerGroup();
  zones.forEach(zone => {
    const color = zone.riskLevel==='high'?COLORS.red:zone.riskLevel==='medium'?COLORS.orange:COLORS.green;
    const polygon=L.polygon(zone.polygon,{color,weight:2,fillColor:color,fillOpacity:.24}).on('click',()=>showZoneInsight(zone));
    const label=L.marker(zone.center,{icon:L.divIcon({className:'custom-zone-label',html:`<div class="zone-label ${zone.riskLevel}">${zone.name} · ${zone.risk}%</div>`,iconAnchor:[38,10]})}).on('click',()=>showZoneInsight(zone));
    zoneGroup.addLayer(polygon).addLayer(label);
  });
  zoneGroup.addTo(map); mapState.layers.floodZones = zoneGroup;

  const drainGroup = L.layerGroup();
  drains.forEach(d => { const c=drainStyle(d.status); drainGroup.addLayer(L.circleMarker([d.lat,d.lng],{radius:6,fillColor:c.fill,color:c.stroke,weight:2,fillOpacity:.95}).bindTooltip(`${d.id}: ${d.status}`).on('click',()=>showDrainInsight(d))); });
  drainGroup.addTo(map); mapState.layers.drains=drainGroup;

  const dumpGroup = L.layerGroup();
  dumpsites.forEach(d => dumpGroup.addLayer(L.circleMarker([d.lat,d.lng],{radius:7+Math.min(3,d.tonnes/3),fillColor:'#5c6570',color:'#f4f6f8',weight:2,fillOpacity:.92}).bindTooltip(`${d.id}: ${d.tonnes} t`).on('click',()=>showDumpInsight(d))));
  dumpGroup.addTo(map); mapState.layers.dumpsites=dumpGroup;

  const riverGroup = L.layerGroup();
  riverLines.forEach(line=>riverGroup.addLayer(L.polyline(line,{color:'#2d8bc9',weight:5,opacity:.65}))); riverGroup.addTo(map); mapState.layers.rivers=riverGroup;

  const schoolGroup=L.layerGroup(), clinicGroup=L.layerGroup();
  assets.forEach(a=>{
    const html=`<div class="asset-marker ${a.type}">${safeIcon(a.type==='school'?'school':'hospital',12)}</div>`;
    const marker=L.marker([a.lat,a.lng],{icon:L.divIcon({className:'',html,iconSize:[24,24],iconAnchor:[12,12]})}).on('click',()=>showAssetInsight(a));
    (a.type==='school'?schoolGroup:clinicGroup).addLayer(marker);
  });
  schoolGroup.addTo(map);clinicGroup.addTo(map);mapState.layers.schools=schoolGroup;mapState.layers.clinics=clinicGroup;

  const roadGroup=L.layerGroup();roadLines.forEach(line=>roadGroup.addLayer(L.polyline(line,{color:'#666',weight:4,opacity:.55,dashArray:'8 6'})));mapState.layers.roads=roadGroup;
  const populationGroup=L.layerGroup();zones.forEach(z=>populationGroup.addLayer(L.circle(z.center,{radius:Math.sqrt(z.population)*23,color:COLORS.purple,weight:1,fillColor:COLORS.purple,fillOpacity:.12}).bindTooltip(`${z.name}: ${z.population.toLocaleString()} exposed`)));mapState.layers.population=populationGroup;

  document.querySelectorAll('[data-layer]').forEach(input=>input.addEventListener('change',()=>toggleLayer(input.dataset.layer,input.checked)));
  document.getElementById('resetLayers').addEventListener('click',()=>{
    document.querySelectorAll('[data-layer]').forEach(input=>{input.checked=['rivers','drains','floodZones','dumpsites','schools','clinics'].includes(input.dataset.layer);toggleLayer(input.dataset.layer,input.checked);});
  });
  document.getElementById('locateNairobi').addEventListener('click',()=>map.setView([-1.291,36.838],12));
  document.getElementById('mapSearch').addEventListener('input', e=>searchMap(e.target.value));
  document.getElementById('exportSnapshot').addEventListener('click',exportMapBrief);
  renderIcons(document.getElementById('intelligenceMap'));
}

function toggleLayer(name, enabled) {
  const map=mapState.intelligence;if(!map)return;
  if(name==='satellite'){
    if(enabled){map.removeLayer(mapState.layers.baseStreet);mapState.layers.baseSatellite.addTo(map);}else{map.removeLayer(mapState.layers.baseSatellite);mapState.layers.baseStreet.addTo(map);}return;
  }
  const layer=mapState.layers[name];if(!layer)return;
  if(enabled&&!map.hasLayer(layer)) layer.addTo(map); else if(!enabled&&map.hasLayer(layer)) map.removeLayer(layer);
}

function searchMap(query) {
  const q=query.trim().toLowerCase(); if(!q)return;
  const zone=zones.find(z=>z.name.toLowerCase().includes(q)||z.ward.toLowerCase().includes(q));
  if(zone){mapState.intelligence.fitBounds(zone.polygon,{padding:[25,25]});showZoneInsight(zone);return;}
  const drain=drains.find(d=>d.id.toLowerCase().includes(q)); if(drain){mapState.intelligence.setView([drain.lat,drain.lng],16);showDrainInsight(drain);}
}

function showZoneInsight(zone) {
  const panel=document.getElementById('mapInsightPanel');
  panel.innerHTML=`<div class="insight-content">
    <div class="insight-hero ${zone.riskLevel}"><small>${zone.ward}</small><h3>${zone.name} flood hotspot</h3><div class="risk-number"><strong>${zone.risk}%</strong><span>flood risk</span></div></div>
    <div class="insight-body">
      <div class="insight-metrics"><div class="insight-metric"><span>Blocked drains</span><strong>${zone.blocked}</strong></div><div class="insight-metric"><span>Waste mapped</span><strong>${zone.waste} t</strong></div><div class="insight-metric"><span>People exposed</span><strong>${zone.population.toLocaleString()}</strong></div><div class="insight-metric"><span>Capacity remaining</span><strong>${zone.drainCapacity}%</strong></div></div>
      <div><div class="insight-section-title">Critical infrastructure</div><div class="infrastructure-list">${zone.infrastructure.map(([icon,name,sub])=>`<div class="infrastructure-item"><span>${safeIcon(icon,13)}</span><div><strong>${name}</strong><small>${sub}</small></div></div>`).join('')}</div></div>
      <div><div class="insight-section-title">Recommended intervention</div><div class="action-list">${zone.actions.map(([name,sub])=>`<div class="action-item"><span>${safeIcon('wrench',13)}</span><div><strong>${name}</strong><small>${sub}</small></div></div>`).join('')}</div></div>
      <div class="carbon-box"><div><span>Indicative intervention cost</span><strong>${zone.cost}</strong></div></div>
    </div></div>`;
  renderIcons(panel);
}

function showDrainInsight(d) {
  const risk=d.status==='blocked'?'high':d.status==='over'?'medium':'low';
  const status=d.status==='blocked'?'Fully blocked':d.status==='over'?'Over capacity':'Clear';
  document.getElementById('mapInsightPanel').innerHTML=`<div class="insight-content"><div class="insight-hero ${risk}"><small>${d.zone} drainage asset</small><h3>Drain ${d.id}</h3><div class="risk-number"><strong>${d.capacity}%</strong><span>capacity remaining</span></div></div><div class="insight-body"><div class="insight-metrics"><div class="insight-metric"><span>Status</span><strong>${status}</strong></div><div class="insight-metric"><span>Waste nearby</span><strong>${d.waste}</strong></div><div class="insight-metric"><span>Asset ID</span><strong>${d.id}</strong></div><div class="insight-metric"><span>Zone</span><strong>${d.zone}</strong></div></div><div><div class="insight-section-title">Recommended action</div><div class="action-list"><div class="action-item"><span>${safeIcon('wrench',13)}</span><div><strong>${d.action}</strong><small>Assign, photograph before work, and verify after rainfall.</small></div></div><div class="action-item"><span>${safeIcon('clipboard-check',13)}</span><div><strong>Evidence requirement</strong><small>Before/after photo, GPS, removed volume and supervisor sign-off.</small></div></div></div></div></div></div>`;
  renderIcons(document.getElementById('mapInsightPanel'));
}
function showDumpInsight(d) {
  document.getElementById('mapInsightPanel').innerHTML=`<div class="insight-content"><div class="insight-hero high"><small>${d.zone} waste hotspot</small><h3>Dumpsite ${d.id}</h3><div class="risk-number"><strong>${d.tonnes} t</strong><span>estimated waste</span></div></div><div class="insight-body"><div class="insight-metrics"><div class="insight-metric"><span>Waste type</span><strong>${d.type}</strong></div><div class="insight-metric"><span>Drain nearby</span><strong>${d.nearDrain}</strong></div><div class="insight-metric"><span>Blockage risk</span><strong>${d.risk}</strong></div><div class="insight-metric"><span>Review status</span><strong>Pending</strong></div></div><div><div class="insight-section-title">Recommended action</div><div class="action-list"><div class="action-item"><span>${safeIcon('trash-2',13)}</span><div><strong>Remove and divert waste</strong><small>Prioritise material blocking the drainage inlet.</small></div></div><div class="action-item"><span>${safeIcon('scan-search',13)}</span><div><strong>Verify destination</strong><small>Record where the removed waste was taken.</small></div></div></div></div></div></div>`;
  renderIcons(document.getElementById('mapInsightPanel'));
}
function showAssetInsight(a) {
  document.getElementById('mapInsightPanel').innerHTML=`<div class="insight-content"><div class="insight-hero ${a.exposure==='High'?'high':'medium'}"><small>${a.zone} critical infrastructure</small><h3>${a.name}</h3><div class="risk-number"><strong>${a.exposure}</strong><span>exposure</span></div></div><div class="insight-body"><div class="insight-metrics"><div class="insight-metric"><span>Asset type</span><strong>${a.type==='school'?'School':'Clinic'}</strong></div><div class="insight-metric"><span>People served</span><strong>${a.people}</strong></div></div><div><div class="insight-section-title">Planning implication</div><div class="action-list"><div class="action-item"><span>${safeIcon('route',13)}</span><div><strong>Protect access route</strong><small>Prioritise nearby drains and establish a safe alternative route.</small></div></div></div></div></div></div>`;
  renderIcons(document.getElementById('mapInsightPanel'));
}

function exportMapBrief() {
  const selected = document.querySelector('#mapInsightPanel .insight-content');
  const body = selected ? selected.innerText : 'No hotspot selected. Open WasteMap Africa and select a flood zone or drainage asset.';
  const content = `WASTEMAP AFRICA FLOOD RISK BRIEF\nGenerated: ${new Date().toLocaleString()}\n\nPROTOTYPE NOTICE\nThis brief contains simulated demonstration data and is not for emergency operations.\n\n${body}\n`;
  downloadFile('wastemap-flood-brief.txt',content,'text/plain');
  showToast('Flood brief exported','The selected map details have been downloaded as a text brief.');
}

function initCollector() {
  const fileInput=document.getElementById('sitePhoto');
  fileInput.addEventListener('change',()=>{
    const file=fileInput.files?.[0];if(!file)return;
    const reader=new FileReader();reader.onload=e=>{document.getElementById('photoPreview').src=e.target.result;document.getElementById('photoUploadLabel').classList.add('has-photo');};reader.readAsDataURL(file);
  });
  document.getElementById('captureGps').addEventListener('click',()=>{
    const output=document.getElementById('gpsValue');output.textContent='Capturing location...';
    if(!navigator.geolocation){setTimeout(()=>output.textContent='-1.3133, 36.7862 • ±8 m (demo)',500);return;}
    navigator.geolocation.getCurrentPosition(pos=>{output.textContent=`${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)} • ±${Math.round(pos.coords.accuracy)} m`;showToast('GPS refreshed','The current browser location has been captured.');},()=>{output.textContent='-1.3133, 36.7862 • ±8 m (demo fallback)';showToast('Using demo GPS','Location permission was unavailable, so the prototype coordinate was restored.','error');},{enableHighAccuracy:true,timeout:5000});
  });
  document.getElementById('collectorForm').addEventListener('submit',e=>{
    e.preventDefault();const progress=document.getElementById('validationProgress');
    progress.className='validation-progress active loading';progress.innerHTML='<span class="spinner"></span><span>Uploading evidence and running prototype quality checks...</span>';
    setTimeout(()=>{progress.className='validation-progress active';progress.innerHTML=`${safeIcon('badge-check',14)}<span>GPS and form checks passed. Report queued for supervisor review.</span>`;renderIcons(progress);showToast('Report submitted','A simulated report was added to the supervisor review queue.');e.target.reset();document.getElementById('photoUploadLabel').classList.remove('has-photo');},1300);
  });
}

function initComparison() {
  const slider=document.getElementById('comparisonSlider'), after=document.getElementById('afterArt'), divider=document.getElementById('comparisonDivider');
  slider.addEventListener('input',()=>{const value=slider.value;after.style.clipPath=`inset(0 0 0 ${value}%)`;divider.style.left=`${value}%`;});
  document.querySelectorAll('[data-year]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-year]').forEach(b=>b.classList.toggle('active',b===btn));showToast(`Evidence year: ${btn.dataset.year}`,'Charts remain simulated in this prototype.');}));
  document.getElementById('evidenceBrief').addEventListener('click',()=>{
    downloadFile('wastemap-evidence-brief.txt','WASTEMAP AFRICA - EVIDENCE BRIEF\n\nMathare North Channel\nWaste removed: 48 tonnes\nBlocked drains: 14 to 3\nFlood incidents: 5 to 2\nPeople protected: 9,200\n\nPrototype notice: simulated demonstration data.\n','text/plain');
    showToast('Evidence brief downloaded','The demonstration impact summary is ready.');
  });
}

function initEvidenceCharts() {
  if(chartInstances.floodFrequency)return;
  const years=['2022','2023','2024','2025','2026'];
  chartInstances.floodFrequency=new Chart(document.getElementById('floodFrequencyChart'),{type:'line',data:{labels:years,datasets:[{data:[12,13,11,8,5],borderColor:COLORS.red,backgroundColor:'rgba(211,47,47,.08)',fill:true,tension:.35,pointRadius:2}]},options:chartOptions()});
  chartInstances.wasteRemoved=new Chart(document.getElementById('wasteRemovedChart'),{type:'bar',data:{labels:years,datasets:[{data:[0,42,156,338,514],backgroundColor:COLORS.green,borderRadius:4}]},options:chartOptions()});
  chartInstances.blockedDrains=new Chart(document.getElementById('blockedDrainsChart'),{type:'line',data:{labels:years,datasets:[{data:[735,701,650,523,412],borderColor:COLORS.orange,backgroundColor:'rgba(251,140,0,.08)',fill:true,tension:.35,pointRadius:2}]},options:chartOptions()});
  chartInstances.participation=new Chart(document.getElementById('participationChart'),{type:'bar',data:{labels:years,datasets:[{data:[0,180,720,1640,2840],backgroundColor:COLORS.blue,borderRadius:4}]},options:chartOptions()});
}

function renderRecommendations() {
  const list=document.getElementById('recommendationList');
  list.innerHTML=recommendations.map(r=>`<article class="recommendation-card ${r.id===selectedRecommendation.id?'active':''}" data-rec="${r.id}"><span class="rank-badge">${r.rank}</span><div class="rec-main"><span>${r.location}</span><strong>${r.title}</strong><small>${r.evidence}</small></div><div class="rec-stat"><span>Priority</span><strong class="star-rating">${'★'.repeat(r.priority)}${'☆'.repeat(5-r.priority)}</strong></div><div class="rec-stat"><span>Flood reduction</span><strong>${r.reduction}%</strong></div><div class="rec-stat"><span>Cost</span><strong>KES ${r.cost}M</strong></div><div class="rec-stat"><span>People protected</span><strong>${r.population.toLocaleString()}</strong></div><span class="rec-arrow">${safeIcon('chevron-right',16)}</span></article>`).join('');
  list.querySelectorAll('[data-rec]').forEach(card=>card.addEventListener('click',()=>{selectedRecommendation=recommendations.find(r=>r.id===card.dataset.rec);renderRecommendations();}));
  renderRecommendationDetail(selectedRecommendation);renderIcons(list);
}

function renderRecommendationDetail(r) {
  const detail=document.getElementById('recommendationDetail');
  detail.innerHTML=`<div class="detail-head"><span>PRIORITY #${r.rank}</span><h3>${r.location}</h3><p>${r.title}</p></div><div class="detail-score"><div><span>Expected flood reduction</span><strong>${r.reduction}%</strong></div><div><span>Population protected</span><strong>${r.population.toLocaleString()}</strong></div><div><span>Estimated cost</span><strong>KES ${r.cost}M</strong></div></div><div class="detail-section"><h4>Why this ranks highly</h4><ul><li>${safeIcon('triangle-alert',14)}<span>${r.evidence}</span></li><li>${safeIcon('clock-3',14)}<span>Recommended start: ${r.time}</span></li><li>${safeIcon('building-2',14)}<span>Lead team: ${r.owner}</span></li></ul><h4>Action plan</h4><ul>${r.steps.map(step=>`<li>${safeIcon('check-circle-2',14)}<span>${step}</span></li>`).join('')}</ul></div><button class="primary-button detail-cta" id="assignAction">${safeIcon('user-plus',15)}Assign intervention</button>`;
  renderIcons(detail);document.getElementById('assignAction').addEventListener('click',()=>showToast('Action assigned',`${r.location} has been added to the action list.`));
}

function initBudgetScenarios() {
  const scenarios={5:{actions:2,people:'15,600',cost:'KES 4.6M'},15:{actions:4,people:'31,800',cost:'KES 14.2M'},25:{actions:6,people:'36,500',cost:'KES 14.2M'}};
  document.querySelectorAll('[data-budget]').forEach(btn=>btn.addEventListener('click',()=>{
    document.querySelectorAll('[data-budget]').forEach(b=>b.classList.toggle('active',b===btn));const s=scenarios[btn.dataset.budget];
    document.getElementById('immediateActions').textContent=s.actions;document.getElementById('protectedPeople').textContent=s.people;document.getElementById('portfolioCost').textContent=s.cost;showToast(`KES ${btn.dataset.budget}M scenario applied`,`${s.actions} interventions fit within the selected response budget.`);
  }));
}

function downloadFile(filename,content,type) {
  const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}
function showToast(title,message,type='success') {
  const container=document.getElementById('toastContainer');const toast=document.createElement('div');toast.className=`toast ${type}`;toast.innerHTML=`${safeIcon(type==='error'?'circle-alert':'check-circle-2',17)}<div><strong>${title}</strong><span>${message}</span></div>`;container.appendChild(toast);renderIcons(toast);setTimeout(()=>toast.remove(),4200);
}

function initMisc() {
  document.getElementById('dismissDisclaimer').addEventListener('click',e=>e.currentTarget.closest('.demo-disclaimer').remove());
  window.addEventListener('resize',()=>{mapState.dashboard?.invalidateSize();mapState.intelligence?.invalidateSize();});
}

function boot() {
  renderIcons();renderAlerts();initNavigation();initCollector();initComparison();initBudgetScenarios();initMisc();
}

document.addEventListener('DOMContentLoaded',boot);
