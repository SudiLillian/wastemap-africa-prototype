# WasteMap Africa Flood Risk Prototype

A browser prototype showing how community waste and drainage reports can help county teams identify flood risk and plan a response.

## What is included

1. Executive dashboard with simulated flood KPIs and recent alerts
2. Interactive Leaflet map using real Nairobi-area coordinates and clickable flood zones, drains, dumpsites, schools and clinics
3. Mobile field reporting workflow with photo preview, browser geolocation and supervisor review
4. Historical before/after evidence slider and impact charts
5. Priority actions with budget scenarios
6. Project purpose, risk method, pilot setup and growth path
7. Plain-language interview preparation notes

> All scores, alerts, exposure figures and impact results are simulated demonstration data. This prototype is not for emergency operations.

## Run locally

The easiest option is to open `index.html` in Chrome or Edge. For more reliable browser permissions and map behaviour, serve the folder locally:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Fastest hosting: Netlify Drop

1. Unzip the project.
2. Open Netlify Drop in your browser.
3. Drag the **entire `wastemap-africa-live` folder** into the deploy zone.
4. Netlify will publish a public `netlify.app` URL.
5. In the Netlify project dashboard, choose **Customize** to rename the URL, for example `wastemap-africa-demo.netlify.app` if available.

The project is already static and deploy-ready. There is no build command and the publish directory is the project root (`.`).

## GitHub Pages alternative

1. Create a repository such as `wastemap-africa-prototype`.
2. Upload all project files so `index.html` is at the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

## External services used

- OpenStreetMap tiles through Leaflet
- Optional Esri satellite imagery layer
- Chart.js for charts (bundled locally)
- Lucide for interface icons (bundled locally)
- Leaflet application files (bundled locally)

An internet connection is required only for the live OpenStreetMap or satellite map tiles. The interface, charts and icons are bundled with the project.


## Interview notes

See `INTERVIEW_PREP.md` for plain-language answers on obstacles and funding scenarios.
